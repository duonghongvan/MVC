﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BanHang_MVC.Models;
using System.Web.Mvc;
using PagedList;

namespace BanHang_MVC.Controllers
{
    public class SanPhamController : Controller
    {
        SinhVienEntities sinhVienEntities = new SinhVienEntities();
        // GET: SanPham
        public ActionResult Index(string CurrentFilter, string SearchString, int? page)
        {
            var listSanPham = new List<SanPham>();
            if (SearchString != null)
            {
                page = 1;
            }
            else
            {
                SearchString = CurrentFilter;
            }
            if (!string.IsNullOrEmpty(SearchString))
            {
                //lấy ds  sản phẩm theo từ khóa tìm kiếm
                listSanPham = sinhVienEntities.SanPhams.Where(n => n.TenSP.Contains(SearchString)).ToList();
            }
            else
            {
                //lấy all sản phẩm trong bẳng sanpham
                listSanPham = sinhVienEntities.SanPhams.ToList();
            }
            ViewBag.CurrentFilter = SearchString;
            int pageSize = 4;
            int pageNumber = (page ?? 1);
            listSanPham = listSanPham.OrderByDescending(n => n.MaSP).ToList();
            //var listLoaiSanPham = new ModelQAShop().LoaiQA_PhuKien.ToList();
            return View(listSanPham.ToPagedList(pageNumber, pageSize));
        }

        // GET: SanPham/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SanPham/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SanPham/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SanPham/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SanPham/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SanPham/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SanPham/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
